const b = 1;

console.log(a);
